import json
import io
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..assessment.databricks import DatabricksAssessment

# Import assessment dataclasses
from ..assessment.synapse import SynapseAssessment
from ..utils import ui as utils_ui
from ..utils.output_paths import (
    OutputPathAdapter,
    format_path_error,
)


class ExportPlan:
    """Ordered filesystem operations rendered before any workspace mutation."""

    def __init__(self, adapter: OutputPathAdapter) -> None:
        self.adapter = adapter
        self.operations: list[tuple[str, str, Any]] = []

    def add_directory(self, path: Path, *, parents: bool, exist_ok: bool) -> None:
        self.operations.append(
            ("mkdir", self.adapter.normalize(path), (parents, exist_ok))
        )

    def add_write(self, path: Path, content: str) -> None:
        self.operations.append(("write", self.adapter.normalize(path), content))

    def add_remove_tree(self, path: Path) -> None:
        self.operations.append(("remove_tree", self.adapter.normalize(path), None))

    @property
    def files(self) -> list[str]:
        return [path for operation, path, _ in self.operations if operation == "write"]

    @property
    def directories(self) -> list[str]:
        return [
            path for operation, path, _ in self.operations if operation == "mkdir"
        ] + [
            path for operation, path, _ in self.operations if operation == "remove_tree"
        ]

    def execute(self) -> None:
        for operation, path, value in self.operations:
            if operation == "mkdir":
                parents, exist_ok = value
                self.adapter.mkdir(path, parents=parents, exist_ok=exist_ok)
            elif operation == "remove_tree":
                if self.adapter.exists(path):
                    self.adapter.remove_tree(path)
            else:
                with self.adapter.open(path, "w", encoding="utf-8") as stream:
                    stream.write(value)


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super().default(obj)


class BaseExporter(ABC):
    """Base class for different export formats."""

    @abstractmethod
    def export(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        output_path: str,
        workspace_name: str,
        *,
        output_adapter: Optional[OutputPathAdapter] = None,
        legacy_path_limit: bool = False,
    ) -> Dict[str, Any]:
        """Export assessment data in specific format."""
        pass


class JSONExporter(BaseExporter):
    """JSON format exporter with structured folder output."""

    def __init__(self) -> None:
        self._adapter: Optional[OutputPathAdapter] = None
        self._plan: Optional[ExportPlan] = None

    def export(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        output_path: str,
        workspace_name: str,
        resources: Optional[List[str]] = None,
        *,
        output_adapter: Optional[OutputPathAdapter] = None,
        legacy_path_limit: bool = False,
    ) -> Dict[str, Any]:
        self._adapter = output_adapter or OutputPathAdapter(output_path)
        self._plan = ExportPlan(self._adapter)
        try:
            result = self._render_export(
                assessment_data, output_path, workspace_name, resources=resources
            )
            path_error = format_path_error(
                workspace_name,
                self._adapter,
                self._plan.files,
                self._plan.directories,
                legacy_limit=legacy_path_limit,
            )
            if path_error:
                raise path_error
            self._plan.execute()
            return result
        finally:
            self._plan = None

    def _render_export(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        output_path: str,
        workspace_name: str,
        resources: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Export assessment data as structured JSON files in folders.

        When resources is specified, only the listed resource folders are
        cleared and rewritten. Summary is always rewritten.
        """
        workspace_dir = Path(output_path) / workspace_name
        self._mkdir(workspace_dir, parents=True, exist_ok=True)

        # Convert dataclass to dictionary
        data = asdict(assessment_data)

        # Create summary with high-level workspace information (always rewritten)
        summary = assessment_data.get_summary()

        # In partial mode, preserve existing summary counts for resources not re-extracted
        summary_path = workspace_dir / "summary.json"
        if resources and self._exists(summary_path):
            try:
                with self._open(summary_path, "r", encoding="utf-8") as f:
                    existing_summary = json.load(f)
                existing_counts = existing_summary.get("counts", {})
                new_counts = summary.get("counts", {})
                # For each count key, keep the existing value if the corresponding
                # resource was not re-extracted (new value would be 0 from empty stub)
                resource_to_count_keys = {
                    "clusters": ["clusters"],
                    "sql_warehouses": ["sql_warehouses"],
                    "notebooks": ["notebooks"],
                    "jobs": ["jobs"],
                    "catalogs": [
                        "catalogs",
                        "total_databases",
                        "total_tables",
                        "total_volumes",
                        "total_functions",
                    ],
                    "external_locations": ["external_locations"],
                    "connections": ["connections"],
                    "secret_scopes": ["secret_scopes"],
                    "pipelines": ["pipelines"],
                    "repos": ["repos"],
                    "experiments": ["experiments"],
                    "serving_endpoints": ["serving_endpoints"],
                    "alerts": ["alerts"],
                    "genie_spaces": ["genie_spaces"],
                    "cluster_policies": ["cluster_policies"],
                    "instance_pools": ["instance_pools"],
                }
                for res_name, count_keys in resource_to_count_keys.items():
                    if res_name not in resources:
                        for key in count_keys:
                            if key in existing_counts:
                                new_counts[key] = existing_counts[key]
                summary["counts"] = new_counts
            except (json.JSONDecodeError, IOError):
                pass

        with self._open(summary_path, "w") as f:
            json.dump(summary, f, indent=2, cls=DecimalEncoder)

        # Export detailed components to separate folders
        files_created = [str(summary_path)]

        if isinstance(assessment_data, SynapseAssessment):
            files_created.extend(self._export_synapse_details(data, workspace_dir))
        elif isinstance(assessment_data, DatabricksAssessment):
            files_created.extend(
                self._export_databricks_details(
                    data, workspace_dir, resources=resources
                )
            )

        return {
            "format": "json",
            "workspace_directory": str(workspace_dir),
            "files_created": files_created,
            "total_files": len(files_created),
        }

    @contextmanager
    def _open(self, path: Path, mode: str, **kwargs):
        if self._adapter is None:
            raise RuntimeError("Output path adapter is not configured.")
        if "r" in mode:
            with self._adapter.open(path, mode, **kwargs) as stream:
                yield stream
            return

        if self._plan is None:
            raise RuntimeError("Export plan is not active.")
        buffer = io.StringIO()
        try:
            yield buffer
        except BaseException:
            raise
        else:
            self._plan.add_write(path, buffer.getvalue())
        finally:
            buffer.close()

    def _mkdir(
        self, path: Path, *, parents: bool = False, exist_ok: bool = False
    ) -> None:
        if self._plan is None:
            raise RuntimeError("Export plan is not active.")
        self._plan.add_directory(path, parents=parents, exist_ok=exist_ok)

    def _exists(self, path: Path) -> bool:
        if self._adapter is None:
            raise RuntimeError("Output path adapter is not configured.")
        return self._adapter.exists(path)

    def _remove_tree(self, path: Path) -> None:
        if self._plan is None:
            raise RuntimeError("Export plan is not active.")
        self._plan.add_remove_tree(path)

    def _export_component(
        self,
        data,
        key,
        resources_dir,
        folder_name,
        file_type,
        files_created,
        property=None,
    ):
        """Helper function to export a specific component."""

        if not property:
            property = key

        if key in data:
            component_dir = resources_dir / folder_name
            self._mkdir(component_dir, exist_ok=True)

            for item in data[key].get(property, []):
                file_path = component_dir / f"{item['name']}.json"
                with self._open(file_path, "w") as f:
                    json.dump(
                        {
                            "type": file_type,
                            "data": item,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(file_path))

    def _export_synapse_details(
        self, data: Dict[str, Any], workspace_dir: Path
    ) -> List[str]:
        """Export Synapse-specific detailed components."""
        files_created = []

        # Create workspace directory
        ws_dir = workspace_dir
        self._mkdir(ws_dir, exist_ok=True)

        # Export general workspace info
        workspace_info_file = ws_dir / "workspace.json"
        with self._open(workspace_info_file, "w") as f:
            json.dump(
                {
                    "type": "synapse_workspace",
                    "workspace": data.get("workspace_info", {}),
                    "exported_at": datetime.now().isoformat(),
                },
                f,
                indent=2,
                cls=DecimalEncoder,
            )
        files_created.append(str(workspace_info_file))

        # Create resources folder
        resources_dir = workspace_dir / "resources"
        self._mkdir(resources_dir, exist_ok=True)

        # Export SQL pools
        if "sql_pools" in data:
            sql_pools_dir = resources_dir / "sql_pools"
            self._mkdir(sql_pools_dir, exist_ok=True)

            # Dedicated pools
            for i, pool in enumerate(data["sql_pools"].get("dedicated_pools", [])):
                pool_file = sql_pools_dir / f"dedicated_pool_{pool['name']}.json"
                with self._open(pool_file, "w") as f:
                    json.dump(
                        {
                            "type": "dedicated_pool",
                            "pool_data": pool,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(pool_file))

            # Serverless pools
            for i, pool in enumerate(data["sql_pools"].get("serverless_pools", [])):
                pool_file = sql_pools_dir / f"serverless_pool_{pool['name']}.json"
                with self._open(pool_file, "w") as f:
                    json.dump(
                        {
                            "type": "serverless_pool",
                            "pool_data": pool,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(pool_file))

        # Export Spark pools
        self._export_component(
            data,
            "spark_pools",
            resources_dir,
            "spark_pools",
            "spark_pool",
            files_created,
        )

        # Export pipelines
        self._export_component(
            data, "pipelines", resources_dir, "pipelines", "pipeline", files_created
        )

        # Export Spark Job Definitions (sjds)
        self._export_component(
            data,
            "spark_job_definitions",
            resources_dir,
            "spark_job_definitions",
            "spark_job_definition",
            files_created,
        )

        # Export notebooks
        self._export_component(
            data, "notebooks", resources_dir, "notebooks", "notebook", files_created
        )

        # Export Dataflows
        self._export_component(
            data, "dataflows", resources_dir, "dataflows", "dataflow", files_created
        )

        # Export SQL Scripts
        self._export_component(
            data,
            "sql_scripts",
            resources_dir,
            "sql_scripts",
            "sql_script",
            files_created,
        )

        # Create admin folder
        admin_dir = workspace_dir / "admin"
        self._mkdir(admin_dir, exist_ok=True)

        # Export Integration Runtimes
        self._export_component(
            data,
            "integration_runtimes",
            admin_dir,
            "integration_runtimes",
            "integration_runtime",
            files_created,
        )

        # Export Linked Services
        self._export_component(
            data,
            "linked_services",
            admin_dir,
            "linked_services",
            "linked_service",
            files_created,
        )

        # Export Datasets
        self._export_component(
            data, "datasets", admin_dir, "datasets", "dataset", files_created
        )

        # Export Managed Private Endpoints
        self._export_component(
            data,
            "managed_private_endpoints",
            admin_dir,
            "managed_private_endpoints",
            "managed_private_endpoint",
            files_created,
        )

        # Export Libraries
        self._export_component(
            data, "libraries", admin_dir, "libraries", "library", files_created
        )

        # Export Spark Configurations
        self._export_component(
            data,
            "spark_configurations",
            admin_dir,
            "spark_configurations",
            "spark_configuration",
            files_created,
        )

        # Create data folder
        data_dir = workspace_dir / "data"
        self._mkdir(data_dir, exist_ok=True)

        # Export Serverless Databases with hierarchical structure
        self._export_synapse_serverless_databases(data, data_dir, files_created)

        # Export Dedicated Databases with hierarchical structure
        self._export_synapse_dedicated_databases(data, data_dir, files_created)

        return files_created

    def _export_synapse_serverless_databases(
        self, data: Dict[str, Any], data_dir: Path, files_created: List[str]
    ):
        """Export Synapse serverless databases with hierarchical structure."""
        if "sql_pools" not in data:
            return

        serverless_databases_dir = data_dir / "serverless_databases"
        self._mkdir(serverless_databases_dir, exist_ok=True)

        databases = (
            data["sql_pools"]
            .get("serverless_pool", {})
            .get("databases", {})
            .get("databases", [])
        )

        for database in databases:
            db_name = database.get("name", "unknown")
            db_dir = serverless_databases_dir / "databases" / db_name
            self._mkdir(db_dir, parents=True, exist_ok=True)

            # Export database info
            db_file = db_dir / f"{db_name}.json"
            db_info = {
                key: value for key, value in database.items() if key != "schemas"
            }
            with self._open(db_file, "w") as f:
                json.dump(
                    {
                        "type": "serverless_database",
                        "data": db_info,
                        "exported_at": datetime.now().isoformat(),
                    },
                    f,
                    indent=2,
                    cls=DecimalEncoder,
                )
            files_created.append(str(db_file))

            # Export schemas
            if "schemas" in database and "schemas" in database["schemas"]:
                schemas_dir = db_dir / "schemas"
                self._mkdir(schemas_dir, exist_ok=True)

                for schema in database["schemas"]["schemas"]:
                    schema_name = schema.get("name", "unknown")
                    schema_dir = schemas_dir / schema_name
                    self._mkdir(schema_dir, exist_ok=True)

                    # Export schema info
                    schema_file = schema_dir / f"{schema_name}.json"
                    schema_info = {
                        key: value
                        for key, value in schema.items()
                        if key not in ["tables", "views"]
                    }
                    with self._open(schema_file, "w") as f:
                        json.dump(
                            {
                                "type": "schema",
                                "data": schema_info,
                                "exported_at": datetime.now().isoformat(),
                            },
                            f,
                            indent=2,
                            cls=DecimalEncoder,
                        )
                    files_created.append(str(schema_file))

                    # Export tables
                    if "tables" in schema and "tables" in schema["tables"]:
                        tables_dir = schema_dir / "tables"
                        self._mkdir(tables_dir, exist_ok=True)

                        for table in schema["tables"]["tables"]:
                            table_name = table.get("name", "unknown")
                            table_file = tables_dir / f"{table_name}.json"
                            with self._open(table_file, "w") as f:
                                json.dump(
                                    {
                                        "type": "table",
                                        "data": table,
                                        "exported_at": datetime.now().isoformat(),
                                    },
                                    f,
                                    indent=2,
                                    cls=DecimalEncoder,
                                )
                            files_created.append(str(table_file))

                    # Export views
                    if "views" in schema and "views" in schema["views"]:
                        views_dir = schema_dir / "views"
                        self._mkdir(views_dir, exist_ok=True)

                        for view in schema["views"]["views"]:
                            view_name = view.get("name", "unknown")
                            view_file = views_dir / f"{view_name}.json"
                            with self._open(view_file, "w") as f:
                                json.dump(
                                    {
                                        "type": "view",
                                        "data": view,
                                        "exported_at": datetime.now().isoformat(),
                                    },
                                    f,
                                    indent=2,
                                    cls=DecimalEncoder,
                                )
                            files_created.append(str(view_file))

    def _export_synapse_dedicated_databases(
        self, data: Dict[str, Any], data_dir: Path, files_created: List[str]
    ):
        """Export Synapse dedicated databases with hierarchical structure."""
        if "sql_pools" not in data:
            return

        dedicated_databases_dir = data_dir / "dedicated_databases"
        self._mkdir(dedicated_databases_dir, exist_ok=True)

        # Process dedicated pools which contain databases
        for pool in data["sql_pools"].get("dedicated_pools", []):
            pool_name = pool.get("name", "unknown")
            if "database" in pool:
                database = pool["database"]
                db_name = database.get("name", "unknown")
                db_dir = dedicated_databases_dir / "databases" / db_name
                self._mkdir(db_dir, parents=True, exist_ok=True)

                # Export database info
                db_file = db_dir / f"{db_name}.json"
                db_info = {
                    key: value for key, value in database.items() if key != "schemas"
                }
                db_info["pool_name"] = pool_name  # Add reference to the pool
                with self._open(db_file, "w") as f:
                    json.dump(
                        {
                            "type": "dedicated_database",
                            "data": db_info,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(db_file))

                # Export schemas
                if "schemas" in database and "schemas" in database["schemas"]:
                    schemas_dir = db_dir / "schemas"
                    self._mkdir(schemas_dir, exist_ok=True)

                    for schema in database["schemas"]["schemas"]:
                        schema_name = schema.get("name", "unknown")
                        schema_dir = schemas_dir / schema_name
                        self._mkdir(schema_dir, exist_ok=True)

                        # Export schema info
                        schema_file = schema_dir / f"{schema_name}.json"
                        schema_info = {
                            key: value
                            for key, value in schema.items()
                            if key not in ["tables", "views"]
                        }
                        with self._open(schema_file, "w") as f:
                            json.dump(
                                {
                                    "type": "schema",
                                    "data": schema_info,
                                    "exported_at": datetime.now().isoformat(),
                                },
                                f,
                                indent=2,
                                cls=DecimalEncoder,
                            )
                        files_created.append(str(schema_file))

                        # Export tables
                        if "tables" in schema and "tables" in schema["tables"]:
                            tables_dir = schema_dir / "tables"
                            self._mkdir(tables_dir, exist_ok=True)

                            for table in schema["tables"]["tables"]:
                                table_name = table.get("name", "unknown")
                                table_file = tables_dir / f"{table_name}.json"
                                with self._open(table_file, "w") as f:
                                    json.dump(
                                        {
                                            "type": "table",
                                            "data": table,
                                            "exported_at": datetime.now().isoformat(),
                                        },
                                        f,
                                        indent=2,
                                        cls=DecimalEncoder,
                                    )
                                files_created.append(str(table_file))

                        # Export views
                        if "views" in schema and "views" in schema["views"]:
                            views_dir = schema_dir / "views"
                            self._mkdir(views_dir, exist_ok=True)

                            for view in schema["views"]["views"]:
                                view_name = view.get("name", "unknown")
                                view_file = views_dir / f"{view_name}.json"
                                with self._open(view_file, "w") as f:
                                    json.dump(
                                        {
                                            "type": "view",
                                            "data": view,
                                            "exported_at": datetime.now().isoformat(),
                                        },
                                        f,
                                        indent=2,
                                        cls=DecimalEncoder,
                                    )
                                files_created.append(str(view_file))

    @staticmethod
    def _safe_filename(name: str) -> str:
        """Create a filesystem-safe filename from a string."""
        return (
            "".join(c for c in str(name) if c.isalnum() or c in ("-", "_", "."))
            .strip()
            .replace(" ", "_")
        ) or "unknown"

    def _export_databricks_details(
        self,
        data: Dict[str, Any],
        workspace_dir: Path,
        resources: Optional[List[str]] = None,
    ) -> List[str]:
        """Export Databricks-specific detailed components.

        When resources is specified, only those resource folders are cleared and
        rewritten. Other folders are left untouched on disk.
        """
        files_created = []

        # Create resources folder
        resources_dir = workspace_dir / "resources"
        self._mkdir(resources_dir, exist_ok=True)

        # Helper: should this resource be exported?
        _should_export = (lambda r: r in resources) if resources else (lambda r: True)

        # Helper: clear a resource folder before rewriting
        def _clear_folder(folder: Path):
            if self._exists(folder):
                self._remove_tree(folder)
            self._mkdir(folder, exist_ok=True)

        # Export clusters
        if "clusters" in data and _should_export("clusters"):
            clusters_dir = resources_dir / "clusters"
            _clear_folder(clusters_dir)

            for cluster in data["clusters"].get("clusters", []):
                cluster_file = clusters_dir / f"cluster_{cluster['cluster_name']}.json"
                with self._open(cluster_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_cluster",
                            "cluster_data": cluster,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(cluster_file))

        # Export jobs
        if "jobs" in data and _should_export("jobs"):
            jobs_dir = resources_dir / "jobs"
            _clear_folder(jobs_dir)

            for job in data["jobs"].get("jobs", []):
                job_file = jobs_dir / f"job_{job['job_id']}.json"
                with self._open(job_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_job",
                            "job_data": job,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(job_file))

        # Create data folder and export hierarchical structure
        data_dir = workspace_dir / "data"
        self._mkdir(data_dir, exist_ok=True)

        # Export legacy databases (non-Unity Catalog)
        self._export_databricks_legacy_databases(data, data_dir, files_created)

        # Export unity catalogs with hierarchical structure
        self._export_databricks_unity_catalogs(data, data_dir, files_created)

        if "sql_warehouses" in data and _should_export("sql_warehouses"):
            sql_wh_dir = resources_dir / "sql_warehouses"
            _clear_folder(sql_wh_dir)
            for wh in data["sql_warehouses"].get("sql_warehouses", []):
                warehouse_id = wh.get("warehouse_id") or "unknown"
                warehouse_name = wh.get("name") or warehouse_id
                safe_name = self._safe_filename(f"{warehouse_name}_{warehouse_id}")
                wh_file = sql_wh_dir / f"warehouse_{safe_name}.json"
                with self._open(wh_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_sql_warehouse",
                            "warehouse_data": wh,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(wh_file))

        # Export notebooks
        if "notebooks" in data and _should_export("notebooks"):
            notebooks_dir = resources_dir / "notebooks"
            _clear_folder(notebooks_dir)

            for i, notebook in enumerate(data["notebooks"].get("notebooks", [])):
                # Export metadata (without content to keep JSON clean)
                nb_export = {k: v for k, v in notebook.items() if k != "content"}
                notebook_file = (
                    notebooks_dir / f"{notebook.get('path').replace('/', '_')}.json"
                )
                with self._open(notebook_file, "w") as f:
                    json.dump(
                        {
                            "type": "notebook",
                            "notebook_data": nb_export,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(notebook_file))

                # Export notebook source content if available
                if notebook.get("content"):
                    sources_dir = workspace_dir / "notebook_sources"
                    self._mkdir(sources_dir, exist_ok=True)
                    nb_path = notebook.get("path", f"notebook_{i}")
                    # Preserve folder structure under notebook_sources/
                    source_file = sources_dir / nb_path.lstrip("/")
                    self._mkdir(source_file.parent, parents=True, exist_ok=True)
                    try:
                        import base64

                        decoded = base64.b64decode(notebook["content"]).decode("utf-8")
                        with self._open(source_file, "w", encoding="utf-8") as f:
                            f.write(decoded)
                        files_created.append(str(source_file))
                    except Exception:
                        pass

        # Export pipelines
        if "pipelines" in data and _should_export("pipelines"):
            pipelines_dir = resources_dir / "pipelines"
            _clear_folder(pipelines_dir)

            for pipeline in data["pipelines"].get("pipelines", []):
                pipeline_id = pipeline.get("pipeline_id") or "unknown"
                pipeline_name = pipeline.get("name") or pipeline_id
                safe_name = self._safe_filename(
                    f"{pipeline_name}_{pipeline_id}"
                    if pipeline_name != pipeline_id
                    else pipeline_id
                )
                pipeline_file = pipelines_dir / f"pipeline_{safe_name}.json"
                with self._open(pipeline_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_pipeline",
                            "pipeline_data": pipeline,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(pipeline_file))

        # Export repos
        if "repos" in data and _should_export("repos"):
            repos_dir = resources_dir / "repos"
            _clear_folder(repos_dir)

            for repo in data["repos"].get("repos", []):
                safe_name = self._safe_filename(
                    repo.get("repo_id") or repo.get("path") or "unknown"
                )
                repo_file = repos_dir / f"repo_{safe_name}.json"
                with self._open(repo_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_repo",
                            "repo_data": repo,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(repo_file))

        # Export experiments
        if "experiments" in data and _should_export("experiments"):
            experiments_dir = resources_dir / "experiments"
            _clear_folder(experiments_dir)

            for experiment in data["experiments"].get("experiments", []):
                safe_name = self._safe_filename(
                    experiment.get("experiment_id", "unknown")
                )
                exp_file = experiments_dir / f"experiment_{safe_name}.json"
                with self._open(exp_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_experiment",
                            "experiment_data": experiment,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(exp_file))

        # Export serving endpoints
        if "serving_endpoints" in data and _should_export("serving_endpoints"):
            endpoints_dir = resources_dir / "serving_endpoints"
            _clear_folder(endpoints_dir)

            for endpoint in data["serving_endpoints"].get("serving_endpoints", []):
                safe_name = self._safe_filename(endpoint.get("name", "unknown"))
                ep_file = endpoints_dir / f"endpoint_{safe_name}.json"
                with self._open(ep_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_serving_endpoint",
                            "endpoint_data": endpoint,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(ep_file))

        # Export alerts
        if "alerts" in data and _should_export("alerts"):
            alerts_dir = resources_dir / "alerts"
            _clear_folder(alerts_dir)

            for alert in data["alerts"].get("alerts", []):
                safe_name = self._safe_filename(alert.get("alert_id", "unknown"))
                alert_file = alerts_dir / f"alert_{safe_name}.json"
                with self._open(alert_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_alert",
                            "alert_data": alert,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(alert_file))

        # Export genie spaces
        if "genie_spaces" in data and _should_export("genie_spaces"):
            genie_dir = resources_dir / "genie_spaces"
            _clear_folder(genie_dir)

            for space in data["genie_spaces"].get("genie_spaces", []):
                safe_name = self._safe_filename(space.get("space_id", "unknown"))
                space_file = genie_dir / f"space_{safe_name}.json"
                with self._open(space_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_genie_space",
                            "space_data": space,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(space_file))

        # Export cluster policies
        if "cluster_policies" in data and _should_export("cluster_policies"):
            policies_dir = resources_dir / "cluster_policies"
            _clear_folder(policies_dir)

            for policy in data["cluster_policies"].get("cluster_policies", []):
                safe_name = self._safe_filename(
                    policy.get("name") or policy.get("policy_id", "unknown")
                )
                policy_file = policies_dir / f"policy_{safe_name}.json"
                with self._open(policy_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_cluster_policy",
                            "cluster_policy_data": policy,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(policy_file))

        # Export instance pools
        if "instance_pools" in data and _should_export("instance_pools"):
            pools_dir = resources_dir / "instance_pools"
            _clear_folder(pools_dir)

            for pool in data["instance_pools"].get("instance_pools", []):
                safe_name = self._safe_filename(
                    pool.get("instance_pool_name")
                    or pool.get("instance_pool_id", "unknown")
                )
                pool_file = pools_dir / f"pool_{safe_name}.json"
                with self._open(pool_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_instance_pool",
                            "instance_pool_data": pool,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(pool_file))

        # Export external locations
        if "external_locations" in data and _should_export("external_locations"):
            ext_dir = resources_dir / "external_locations"
            _clear_folder(ext_dir)

            for ext in data["external_locations"].get("external_locations", []):
                safe_name = self._safe_filename(ext.get("name", "unknown"))
                ext_file = ext_dir / f"external_location_{safe_name}.json"
                with self._open(ext_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_external_location",
                            "external_location_data": ext,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(ext_file))

        # Export connections
        if "connections" in data and _should_export("connections"):
            conn_dir = resources_dir / "connections"
            _clear_folder(conn_dir)

            for conn in data["connections"].get("connections", []):
                safe_name = self._safe_filename(conn.get("name", "unknown"))
                conn_file = conn_dir / f"connection_{safe_name}.json"
                with self._open(conn_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_connection",
                            "connection_data": conn,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(conn_file))

        # Export secret scopes
        if "secret_scopes" in data and _should_export("secret_scopes"):
            scope_dir = resources_dir / "secret_scopes"
            _clear_folder(scope_dir)

            for scope in data["secret_scopes"].get("secret_scopes", []):
                safe_name = self._safe_filename(scope.get("name", "unknown"))
                scope_file = scope_dir / f"secret_scope_{safe_name}.json"
                with self._open(scope_file, "w") as f:
                    json.dump(
                        {
                            "type": "databricks_secret_scope",
                            "secret_scope_data": scope,
                            "exported_at": datetime.now().isoformat(),
                        },
                        f,
                        indent=2,
                        cls=DecimalEncoder,
                    )
                files_created.append(str(scope_file))

        return files_created

    def _export_databricks_legacy_databases(
        self, data: Dict[str, Any], data_dir: Path, files_created: List[str]
    ):
        """Export Databricks legacy databases (non-Unity Catalog)."""
        if "databases" not in data:
            return

        legacy_databases_dir = data_dir / "legacy_databases"
        self._mkdir(legacy_databases_dir, exist_ok=True)

        for database in data["databases"].get("databases", []):
            db_name = database.get("name", "unknown")
            db_dir = legacy_databases_dir / "databases" / db_name
            self._mkdir(db_dir, parents=True, exist_ok=True)

            # Export database info
            db_file = db_dir / f"{db_name}.json"
            with self._open(db_file, "w") as f:
                json.dump(
                    {
                        "type": "legacy_database",
                        "data": database,
                        "exported_at": datetime.now().isoformat(),
                    },
                    f,
                    indent=2,
                    cls=DecimalEncoder,
                )
            files_created.append(str(db_file))

    def _export_databricks_unity_catalogs(
        self, data: Dict[str, Any], data_dir: Path, files_created: List[str]
    ):
        """Export Databricks Unity Catalog structure with hierarchical folders."""
        if "catalogs" not in data:
            return

        unity_catalog_dir = data_dir / "unity_catalog"
        self._mkdir(unity_catalog_dir, exist_ok=True)

        for catalog in data["catalogs"].get("catalogs", []):
            catalog_name = catalog.get("name", "unknown")
            # Create safe filename
            safe_catalog_name = (
                "".join(c for c in catalog_name if c.isalnum() or c in ("-", "_"))
                .strip()
                .replace(" ", "_")
            )

            catalog_dir = unity_catalog_dir / "catalogs" / safe_catalog_name
            self._mkdir(catalog_dir, parents=True, exist_ok=True)

            # Export catalog info
            catalog_file = catalog_dir / f"{safe_catalog_name}.json"
            catalog_info = {
                key: value for key, value in catalog.items() if key != "schemas"
            }
            with self._open(catalog_file, "w") as f:
                json.dump(
                    {
                        "type": "unity_catalog",
                        "data": catalog_info,
                        "exported_at": datetime.now().isoformat(),
                    },
                    f,
                    indent=2,
                    cls=DecimalEncoder,
                )
            files_created.append(str(catalog_file))

            # Export schemas
            if "schemas" in catalog and "schemas" in catalog["schemas"]:
                schemas_dir = catalog_dir / "schemas"
                self._mkdir(schemas_dir, exist_ok=True)

                for schema in catalog["schemas"]["schemas"]:
                    schema_name = schema.get("name", "unknown")
                    schema_dir = schemas_dir / schema_name
                    self._mkdir(schema_dir, exist_ok=True)

                    # Export schema info
                    schema_file = schema_dir / f"{schema_name}.json"
                    schema_info = {
                        key: value
                        for key, value in schema.items()
                        if key not in ["tables", "volumes", "functions"]
                    }
                    with self._open(schema_file, "w") as f:
                        json.dump(
                            {
                                "type": "schema",
                                "data": schema_info,
                                "exported_at": datetime.now().isoformat(),
                            },
                            f,
                            indent=2,
                            cls=DecimalEncoder,
                        )
                    files_created.append(str(schema_file))

                    # Export tables
                    if "tables" in schema:
                        tables_dir = schema_dir / "tables"
                        self._mkdir(tables_dir, exist_ok=True)

                        for table in schema["tables"]:
                            table_name = table.get("name", "unknown")
                            table_file = tables_dir / f"{table_name}.json"
                            with self._open(table_file, "w") as f:
                                json.dump(
                                    {
                                        "type": "table",
                                        "data": table,
                                        "exported_at": datetime.now().isoformat(),
                                    },
                                    f,
                                    indent=2,
                                    cls=DecimalEncoder,
                                )
                            files_created.append(str(table_file))

                    # Export volumes
                    if "volumes" in schema:
                        volumes_dir = schema_dir / "volumes"
                        self._mkdir(volumes_dir, exist_ok=True)

                        for volume in schema["volumes"]:
                            volume_name = volume.get("name", "unknown")
                            volume_file = volumes_dir / f"{volume_name}.json"
                            with self._open(volume_file, "w") as f:
                                json.dump(
                                    {
                                        "type": "volume",
                                        "data": volume,
                                        "exported_at": datetime.now().isoformat(),
                                    },
                                    f,
                                    indent=2,
                                    cls=DecimalEncoder,
                                )
                            files_created.append(str(volume_file))

                    # Export functions
                    if "functions" in schema:
                        functions_dir = schema_dir / "functions"
                        self._mkdir(functions_dir, exist_ok=True)

                        for function in schema["functions"]:
                            function_name = function.get("name", "unknown")
                            function_file = functions_dir / f"{function_name}.json"
                            with self._open(function_file, "w") as f:
                                json.dump(
                                    {
                                        "type": "function",
                                        "data": function,
                                        "exported_at": datetime.now().isoformat(),
                                    },
                                    f,
                                    indent=2,
                                    cls=DecimalEncoder,
                                )
                            files_created.append(str(function_file))


class CSVExporter(BaseExporter):
    """CSV format exporter (scaffolding only)."""

    def export(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        output_path: str,
        workspace_name: str,
        *,
        output_adapter: Optional[OutputPathAdapter] = None,
        legacy_path_limit: bool = False,
    ) -> Dict[str, Any]:
        """Export assessment data as CSV files (scaffolding)."""
        adapter = output_adapter or OutputPathAdapter(output_path)
        workspace_dir = Path(output_path) / workspace_name
        path_error = format_path_error(
            workspace_name, adapter, [], [workspace_dir], legacy_limit=legacy_path_limit
        )
        if path_error:
            raise path_error
        adapter.mkdir(workspace_dir, parents=True, exist_ok=True)

        # TODO: Implement CSV export
        # This would create CSV files for:
        # - summary.csv (workspace summary)
        # - notebooks.csv (all notebooks in one CSV)
        # - pipelines.csv or jobs.csv
        # - sql_pools.csv or clusters.csv
        # - databases.csv and tables.csv

        print(f"CSV export scaffolding - would create CSV files in {workspace_dir}")

        return {
            "format": "csv",
            "workspace_directory": str(workspace_dir),
            "status": "scaffolding_only",
            "message": "CSV export not yet implemented",
        }


class ParquetExporter(BaseExporter):
    """Parquet format exporter (scaffolding only)."""

    def export(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        output_path: str,
        workspace_name: str,
        *,
        output_adapter: Optional[OutputPathAdapter] = None,
        legacy_path_limit: bool = False,
    ) -> Dict[str, Any]:
        """Export assessment data as Parquet files (scaffolding)."""
        adapter = output_adapter or OutputPathAdapter(output_path)
        workspace_dir = Path(output_path) / workspace_name
        path_error = format_path_error(
            workspace_name, adapter, [], [workspace_dir], legacy_limit=legacy_path_limit
        )
        if path_error:
            raise path_error
        adapter.mkdir(workspace_dir, parents=True, exist_ok=True)

        # TODO: Implement Parquet export
        # This would create Parquet files for:
        # - summary.parquet
        # - notebooks.parquet
        # - pipelines.parquet or jobs.parquet
        # - sql_pools.parquet or clusters.parquet
        # - databases.parquet and tables.parquet

        print(
            f"Parquet export scaffolding - would create Parquet files in {workspace_dir}"
        )

        return {
            "format": "parquet",
            "workspace_directory": str(workspace_dir),
            "status": "scaffolding_only",
            "message": "Parquet export not yet implemented",
        }


class StructuredExportService:
    """Service for exporting assessment data in various structured formats."""

    def __init__(self):
        self.exporters = {
            "json": JSONExporter(),
            "csv": CSVExporter(),
            "parquet": ParquetExporter(),
        }

    def export_assessment(
        self,
        assessment_data: Union[SynapseAssessment, DatabricksAssessment],
        workspace_name: str,
        output_path: str,
        format: str = "json",
        resources: Optional[List[str]] = None,
        output_adapter: Optional[OutputPathAdapter] = None,
        legacy_path_limit: bool = False,
    ) -> Dict[str, Any]:
        """
        Export assessment data in specified format.

        Args:
            assessment_data: Assessment dataclass object
            workspace_name: Name of the workspace
            output_path: Base output path (will create subdirectories)
            format: Export format (json, csv, parquet)
            resources: Optional list of resource types that were re-extracted.
                When set, only those resource folders are rewritten.

        Returns:
            Export results dictionary
        """
        if format not in self.exporters:
            raise ValueError(
                f"Unsupported export format: {format}. Supported: {list(self.exporters.keys())}"
            )

        exporter = self.exporters[format]

        utils_ui.print_extracting(
            f"Exporting {workspace_name} assessment data in {format} format"
        )
        if format == "json":
            result = exporter.export(
                assessment_data,
                output_path,
                workspace_name,
                resources=resources,
                output_adapter=output_adapter,
                legacy_path_limit=legacy_path_limit,
            )
        else:
            result = exporter.export(
                assessment_data,
                output_path,
                workspace_name,
                output_adapter=output_adapter,
                legacy_path_limit=legacy_path_limit,
            )
        utils_ui.print_extraction_done(
            f"Exporting {workspace_name} assessment data in {format} format"
        )

        # Add common metadata
        result.update(
            {
                "workspace_name": workspace_name,
                "export_timestamp": datetime.now().isoformat(),
                "export_format": format,
            }
        )

        return result
